
package com.example;

public class Service {
    public static void main(String[] args) {
        System.out.println("Welcome to the Jenkins!");
    }
}
        