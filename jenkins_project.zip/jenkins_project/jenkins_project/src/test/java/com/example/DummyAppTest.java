
package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DummyAppTest {
    @Test
    public void testMain() {
        assertTrue(true, "Dummy test always passes!");
    }
}
        